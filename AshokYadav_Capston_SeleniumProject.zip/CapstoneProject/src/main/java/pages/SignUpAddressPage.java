package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SignUpAddressPage {

	private WebDriverWait wait;
	
	@FindBy(id="addressLineOne")
	private WebElement addLine1;

	@FindBy(id="addressLineTwo")
	private WebElement addLine2;
	
	@FindBy(id="city")
	private WebElement cty;

	@FindBy(id="postalCode")
	private WebElement pstlCode;
	
	@FindBy(id="state")
	private WebElement sTt;

	@FindBy(id="country")
	private WebElement cNtry;

	@FindBy(xpath ="(//div/button[contains(@class, 'btn btn-primary')])[2]")
	private WebElement nextConfirmBtn;

	public SignUpAddressPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, 30);
	}

	public void enterAddressLine1(String aline1) {
		addLine1.clear();
		addLine1.sendKeys(aline1);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void enterAddressLine2(String aline2) {
		addLine2.clear();
		addLine2.sendKeys(aline2);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void enterCity(String ctty) {
		//cty.clear();
		cty.sendKeys(ctty);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	public void enterPostCode(String pstlcde) {
		//pstlCode.clear();
		pstlCode.sendKeys(pstlcde);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

		
	public void enterState(String stt) {
		//cty.clear();
		sTt.sendKeys(stt);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void enterCountry(String cntry) {
		//cNtry.clear();
		cNtry.sendKeys(cntry);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	public void clickNextConfirmBtn() {
		nextConfirmBtn.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	
}
