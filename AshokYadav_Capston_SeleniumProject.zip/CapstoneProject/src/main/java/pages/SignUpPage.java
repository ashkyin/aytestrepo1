package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SignUpPage {

	private WebDriverWait wait;
	
	@FindBy(id="firstName")
	private WebElement frstName;
	
	@FindBy(id="lastName")
	private WebElement lstName;
	
	@FindBy(id="email")
	private WebElement eMail;

	@FindBy(id="contactNumber")
	private WebElement conNumber;
	
	@FindBy(id="password")
	private WebElement pWrd;

	@FindBy(id="confirmPassword")
	private WebElement cPwrd;

	@FindBy(id="role1")
	private WebElement uRole1;
	
	@FindBy(id="role2")
	private WebElement sRole2;

	@FindBy(xpath ="//div/button[contains(@class, 'btn btn-primary')]")
	private WebElement nextBillingbtn;

	
	public SignUpPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, 30);
	}

	public void enterFirstName(String fname) {
		frstName.clear();
		frstName.sendKeys(fname);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void enterLastName(String lname) {
		lstName.clear();
		lstName.sendKeys(lname);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void enterEmail(String email) {
		eMail.clear();
		eMail.sendKeys(email);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void enterContactNumber(String cNum) {
		conNumber.clear();
		conNumber.sendKeys(cNum);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void enterPassword(String pwd) {
			pWrd.clear();
			pWrd.sendKeys(pwd);
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}
	public void enterConfirmPassword(String cpwd) {
		cPwrd.clear();
		cPwrd.sendKeys(cpwd);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void selectRoleUser() {
		uRole1.click();
	}

	public void selectRoleSupplier() {
		sRole2.click();
	}

	public void clickNextBillingBtn() {
		nextBillingbtn.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
}
	
