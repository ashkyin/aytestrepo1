package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class LoggedInHomePage {
	private WebDriverWait wait;

	@FindBy(id = "dropdownMenu1")
	private WebElement loggedUsrName;

	@FindBy(xpath = "//a[text()='Logout']")
	private WebElement logoutOption;

	@FindBy(id = "cart")
	private WebElement cartOption;

	@FindBy(xpath = "(//div/h4[contains(@class, 'pull-right ng-binding')])[1]")
	private WebElement firstMedicine;

	@FindBy(xpath = "(//div/a[contains(@class, 'btn btn-primary pull-right')])[1]")
	private WebElement fstMedViewBtn;

	public LoggedInHomePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, 30);
	}

	public void assertLoggedInUserName() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String actualMessage = loggedUsrName.getText();
		String expectedMessage = "AYFNAME230327142521 AYLNAME230327142521";
		Assert.assertEquals(actualMessage, expectedMessage);
		try {
			System.out.println(actualMessage + "   :  User Logged In");
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(actualMessage + "\n   :  User could not Log In");
		}

	}

	public void assertLoggedInSupplier() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String actualMessage = loggedUsrName.getText();
		String expectedMessage = "AYSUPFNAME230327142521 AYSUPLNAME230327142521";
		Assert.assertEquals(actualMessage, expectedMessage);
		try {
			System.out.println(actualMessage + "   :  Supplier Logged In");
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(actualMessage + "\n   :  Supplier could not Log In");
		}

	}

	public void logoutUser() {
		logoutOption.click();
		;
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/*-- getting error for logout option: element not interactable (Session info: chrome=111.0.5563.111)
	//	Therefore, new to create new script instead of having User and Supplier login in one script as different tests   */

	public String getMedicinePrice() {
		String mprice = firstMedicine.getText();
		return mprice;

	}

	public void clickFirstMedicineViewButton() {
		fstMedViewBtn.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
