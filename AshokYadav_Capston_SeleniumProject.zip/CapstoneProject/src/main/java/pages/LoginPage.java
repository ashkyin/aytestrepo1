package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class LoginPage {

	private WebDriverWait wait;

	@FindBy(id="username")
	private WebElement usrName;
	
	@FindBy(id="password")
	private WebElement usrpwd;
	
	@FindBy(xpath ="//div/input[contains(@class, 'btn btn-primary')]")
	private WebElement loginBtn;
	
	@FindBy(xpath ="//div[contains(@class, 'alert alert-success')]")
	private WebElement loggedOutMsg;
	
	
	public LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, 30);
	}

	public void enterUserName(String uname) {
		usrName.clear();
		usrName.sendKeys(uname);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void enterUserPassword(String upwd) {
		usrpwd.clear();
		usrpwd.sendKeys(upwd);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void clickLoginBtn() {
		loginBtn.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
/*
	public void assertLoggedOutMsg() {
		String actualMessage = loggedOutMsg.getText();
		String expectedMessage = "You have logged out successfully!";
		Assert.assertEquals(actualMessage, expectedMessage);
		try {
			System.out.println(actualMessage + "User has Logged out.");
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(actualMessage + "\nUser could not log out.");
		}

	}*/
	


	
}
