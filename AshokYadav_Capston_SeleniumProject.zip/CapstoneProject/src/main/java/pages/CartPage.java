package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CartPage {
	private WebDriverWait wait;

	@FindBy(xpath="(//table[@id='cart']//td[contains(@data-th, 'Price')])[1]")
	private WebElement medPrice;
	
	public CartPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, 30);
	}

	public String getMedicinePriceInCart() {
		String medcartprice = medPrice.getText();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return medcartprice;
	}
	
}
