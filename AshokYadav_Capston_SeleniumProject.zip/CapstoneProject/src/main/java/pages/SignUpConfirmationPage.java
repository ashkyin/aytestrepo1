package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SignUpConfirmationPage {

	private WebDriverWait wait;

	@FindBy(xpath = "(//div/a[contains(@class, 'btn btn-lg btn-primary')])[1]")
	private WebElement ConfirmBtn;

	public SignUpConfirmationPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, 30);
	}

	public void clickConfirmBtn() {
		ConfirmBtn.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
