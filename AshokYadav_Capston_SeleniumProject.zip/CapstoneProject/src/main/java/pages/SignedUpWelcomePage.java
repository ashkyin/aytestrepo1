package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class SignedUpWelcomePage {

	private WebDriverWait wait;

	@FindBy(xpath = "(//div/div/h1)[1]")
	private WebElement wlcmMsg;

	@FindBy(xpath = "(//div/a[contains(@class, 'navbar-brand')])[1]")
	private WebElement medicareMenuOption;

	public SignedUpWelcomePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, 30);
	}

	public void assertUserWelcomeMsg() {
		String actualMessage = wlcmMsg.getText();
		String expectedMessage = "Welcome!";
		Assert.assertEquals(actualMessage, expectedMessage);
		try {
			System.out.println(actualMessage + "New user signed up");
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(actualMessage + "\nNew user could not sign up");
		}

	}

	public void assertSupplierWelcomeMsg() {
		String actualMessage = wlcmMsg.getText();
		String expectedMessage = "Welcome!";
		Assert.assertEquals(actualMessage, expectedMessage);
		try {
			System.out.println(actualMessage + "New Supplier signed up");
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(actualMessage + "\nNew Supplier could not sign up");
		}

	}

	public void clickMedicareMenuOption() {
		medicareMenuOption.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
