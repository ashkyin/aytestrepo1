package testScripts;

import org.testng.annotations.Test;

import pages.MedicareHomePage;
import pages.LoginPage;
import pages.LoggedInHomePage;

public class LoginAsUser extends BaseTest {

	@Test(priority = 0)
	public void LoginUser() {

		System.out.println("Login as user");
		MedicareHomePage medicareHomePage = new MedicareHomePage(driver);
		medicareHomePage.clickLogin();

		// Login as User
		LoginPage loginPage = new LoginPage(driver);
		loginPage.enterUserName("AYFNAME230327142521@aytsttst.com");
		loginPage.enterUserPassword("AYFNAME230327142521");
		loginPage.clickLoginBtn();

		// Logged in home page appears after log in
		LoggedInHomePage loggedInHomePage = new LoggedInHomePage(driver);
		loggedInHomePage.assertLoggedInUserName();
//		loggedInHomePage.logoutUser(); -- getting error for logout option: element not interactable (Session info: chrome=111.0.5563.111)
//		Therefore, new to create new script instead of having User and Supplier login in one script as different tests

	}


}