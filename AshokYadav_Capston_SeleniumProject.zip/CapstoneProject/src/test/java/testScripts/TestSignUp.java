package testScripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestSignUp {

	WebDriver driver;
	
	@BeforeTest
	public void initApp() {
		System.setProperty("webdriver.chrome.driver", "resources//chromedriver_111.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		// to clear browser cache
		driver.manage().deleteAllCookies();

		driver.get("http://localhost:8080/medicare/home");

	}
	
	@AfterTest
	public void closeBrowser() {
		driver.manage().deleteAllCookies();
		driver.quit();

	}
	
	@Test
	public void HomePage() {
		
	}
}
