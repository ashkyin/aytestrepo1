package testScripts;

import org.testng.annotations.Test;

import pages.LoggedInHomePage;
import pages.LoginPage;
import pages.MedicareHomePage;

public class LoginAsSupplier  extends BaseTest {
	@Test(priority = 0)
	public void LoginSupplier() {

		System.out.println("Login as Supplier");
		MedicareHomePage medicareHomePage = new MedicareHomePage(driver);
		medicareHomePage.clickLogin();

		// Login as User
		LoginPage loginPage = new LoginPage(driver);
		loginPage.enterUserName("AYSUPFNAME230327142521@aytsttst.com");
		loginPage.enterUserPassword("AYSUPFNAME230327142521");
		loginPage.clickLoginBtn();

		// Logged in home page appears after log in
		LoggedInHomePage loggedInHomePage = new LoggedInHomePage(driver);
		loggedInHomePage.assertLoggedInSupplier();
//		loggedInHomePage.logoutUser(); -- getting error for logout option: element not interactable (Session info: chrome=111.0.5563.111)
//		Therefore, new to create new script instead of having User and Supplier login in one script as different tests
	}

}
