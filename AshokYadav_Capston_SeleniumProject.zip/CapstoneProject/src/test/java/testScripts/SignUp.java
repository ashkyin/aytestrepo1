package testScripts;

import org.testng.annotations.Test;
import pages.MedicareHomePage;
import pages.SignUpPage;
import pages.SignUpAddressPage;
import pages.SignUpConfirmationPage;
import pages.SignedUpWelcomePage;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class SignUp extends BaseTest{

	DateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmss");
	Date date = new Date();
	String date1= dateFormat.format(date);
	String emaildt = "AYFNAME" + date1 + "@aytsttst.com";
	String fstname = "AYFNAME" + date1;
	String lstname = "AYLNAME" + date1;
	String psswdt = "AYFNAME" + date1;

	String emaildtsupp = "AYSUPFNAME" + date1 + "@aytsttst.com";
	String fstnamesupp = "AYSUPFNAME" + date1;
	String lstnamesupp = "AYSUPLNAME" + date1;
	String psswdtsupp = "AYSUPFNAME" + date1;

	
	@Test(priority=0)
	public void SignUpUser() {
		
		System.out.println("Signing up the new user");
		MedicareHomePage medicareHomePage = new MedicareHomePage(driver);
		medicareHomePage.clickSignUp();
		
		//Sign up as User
		SignUpPage signUpPage = new SignUpPage(driver);
		signUpPage.enterFirstName(fstname);
		signUpPage.enterLastName(lstname);
		signUpPage.enterEmail(emaildt);
		signUpPage.enterContactNumber("1234567890");
		signUpPage.enterPassword(psswdt);
		signUpPage.enterConfirmPassword(psswdt);
		signUpPage.selectRoleUser();
		signUpPage.clickNextBillingBtn();
	
		//Provide address of user in sign up
		SignUpAddressPage signUpAddressPage = new SignUpAddressPage(driver);
		signUpAddressPage.enterAddressLine1("line1");
		signUpAddressPage.enterAddressLine2("line2");
		signUpAddressPage.enterCity("cityname1");
		signUpAddressPage.enterPostCode("123456");
		signUpAddressPage.enterState("state1");
		signUpAddressPage.enterCountry("country1");
		signUpAddressPage.clickNextConfirmBtn();
	
		//Confirm user details
		SignUpConfirmationPage signUpConfirmationPage = new SignUpConfirmationPage(driver);
		signUpConfirmationPage.clickConfirmBtn();
		
		//Final confirmation
		SignedUpWelcomePage signedUpWelcomePage = new SignedUpWelcomePage(driver);
		signedUpWelcomePage.assertUserWelcomeMsg();
		signedUpWelcomePage.clickMedicareMenuOption();

	}
	
	@Test(priority=1)
	public void SignUpSupplier() {
		
		System.out.println("Signing up the new Supplier");
		MedicareHomePage medicareHomePage = new MedicareHomePage(driver);
		medicareHomePage.clickSignUp();
		
		//Sign up as User
		SignUpPage signUpPage = new SignUpPage(driver);
		signUpPage.enterFirstName(fstnamesupp);
		signUpPage.enterLastName(lstnamesupp);
		signUpPage.enterEmail(emaildtsupp);
		signUpPage.enterContactNumber("1234567890");
		signUpPage.enterPassword(psswdtsupp);
		signUpPage.enterConfirmPassword(psswdtsupp);
		signUpPage.selectRoleSupplier();;
		signUpPage.clickNextBillingBtn();
	
		//Provide address of user in sign up
		SignUpAddressPage signUpAddressPage = new SignUpAddressPage(driver);
		signUpAddressPage.enterAddressLine1("line1");
		signUpAddressPage.enterAddressLine2("line2");
		signUpAddressPage.enterCity("cityname1");
		signUpAddressPage.enterPostCode("123456");
		signUpAddressPage.enterState("state1");
		signUpAddressPage.enterCountry("country1");
		signUpAddressPage.clickNextConfirmBtn();
	
		//Confirm user details
		SignUpConfirmationPage signUpConfirmationPage = new SignUpConfirmationPage(driver);
		signUpConfirmationPage.clickConfirmBtn();
		
		//Final confirmation
		SignedUpWelcomePage signedUpWelcomePage = new SignedUpWelcomePage(driver);
		signedUpWelcomePage.assertSupplierWelcomeMsg();
		signedUpWelcomePage.clickMedicareMenuOption();


	}

}
