package testScripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.LoggedInHomePage;
import pages.LoginPage;
import pages.MedicareHomePage;
import pages.MedicineDetailPage;
import pages.CartPage;

public class VerifyMedicinePrice extends BaseTest {

	@Test(priority = 0)
	public void CheckMedicinePrice() {

		System.out.println("Verifying Medicine prices on Home Page and Cart Page");
		MedicareHomePage medicareHomePage = new MedicareHomePage(driver);
		medicareHomePage.clickLogin();

		// Login as User
		LoginPage loginPage = new LoginPage(driver);
		loginPage.enterUserName("AYFNAME230327142521@aytsttst.com");
		loginPage.enterUserPassword("AYFNAME230327142521");
		loginPage.clickLoginBtn();
		
		LoggedInHomePage loggedInHomePage = new LoggedInHomePage(driver);
		String medPriceOnHomePage = loggedInHomePage.getMedicinePrice() + ".0 /-";
		loggedInHomePage.clickFirstMedicineViewButton();
		
		MedicineDetailPage medicineDetailPage = new MedicineDetailPage(driver);
		medicineDetailPage.clickAddToCartBtn();
		
		CartPage cartPage = new CartPage(driver);
		String medPriceInCart = cartPage.getMedicinePriceInCart();
		
		Assert.assertEquals(medPriceInCart, medPriceOnHomePage);
		try {
			System.out.println(medPriceInCart + "   :  Medicine Price on Cart Page matches with Prices " + medPriceOnHomePage + " on Home Page for the medicine");
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(medPriceInCart + "   :  Medicine Price on Cart Page does not matches with Prices " + medPriceOnHomePage + " on Home Page for the medicine");
		}
	
		
	}
	
	
}
