package testScripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class BaseTest {

	WebDriver driver;
	
	@BeforeTest
	public void launchApplication() {
		System.setProperty("webdriver.chrome.driver", "resources//chromedriver_111.exe");
//		ChromeOptions options = new ChromeOptions();
//		options.addArguments("--remote-allow-origins=*");
//		ChromeDriver driver = new ChromeDriver(options);
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		// to clear browser cache
		driver.manage().deleteAllCookies();

		driver.get("http://localhost:8080/medicare/home");

	}

	@AfterTest
	public void closeBrowser() {
		driver.manage().deleteAllCookies();
		driver.quit();

	}

}
